<?php
// $Id: uc-views-view-row-invoice.tpl.php,v 1.1.2.1 2009/09/29 13:40:01 madsph Exp $

/**
 * @file
 * Patch by hanoii
 */

/**
 * @file uc-views-view-row-invoice.tpl.php
 * Default simple view template to display a single invoice.
 *
 * @ingroup views_templates
 */
?>
<?php print $invoice ?>